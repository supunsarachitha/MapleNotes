---
id: 01a0f227-1ac5-7a92-acab-befb1d6b0bce
kind: note
created: 2026-07-12T19:20:00+00:00
updated: 2026-08-29T21:05:00+00:00
tags: ["reading"]
pinned: false
archived: true
---

# Summer reading list

- [x] The Overstory
- [x] Braiding Sweetgrass
- [x] A Psalm for the Wild-Built

All done. 📚 #reading
