---
id: 01a0ef98-a7da-79c4-95f2-e8a4d572fe3d
kind: note
created: 2026-07-12T19:20:00+00:00
updated: 2026-08-29T21:05:00+00:00
tags: ["reading"]
pinned: false
archived: true
---

# Summer reading list

- [x] The Overstory
- [x] Braiding Sweetgrass
- [x] A Psalm for the Wild-Built

All done. 📚 #reading
