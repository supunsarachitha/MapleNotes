---
id: 01a0ef98-a820-751a-bc4f-06a6747d2684
kind: note
created: 2026-08-26T13:40:00+00:00
updated: 2026-08-26T13:40:00+00:00
tags: ["dev"]
pinned: false
archived: false
---

# Useful one-liners

Find the biggest files in a folder:

```sh
du -ah . | sort -rh | head -20
```

Pretty-print JSON from the clipboard (macOS):

```sh
pbpaste | python3 -m json.tool
```

#dev
