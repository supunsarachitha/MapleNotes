---
id: 01a0f227-1af5-73d2-a9f3-ef19045b4d47
kind: note
created: 2026-08-26T13:40:00+00:00
updated: 2026-08-26T13:40:00+00:00
tags: ["dev"]
pinned: false
archived: false
---

# Useful one-liners

Find the biggest files in a folder:

```sh
du -ah . | sort -rh | head -20
```

Pretty-print JSON from the clipboard (macOS):

```sh
pbpaste | python3 -m json.tool
```

#dev
