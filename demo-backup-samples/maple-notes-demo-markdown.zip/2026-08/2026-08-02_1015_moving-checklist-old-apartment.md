---
id: 01a0ef98-a816-7013-9ff5-5f09928e26bc
kind: note
created: 2026-08-02T10:15:00+00:00
updated: 2026-08-02T10:15:00+00:00
tags: ["home"]
pinned: false
archived: true
---

# Moving checklist (old apartment)

- [x] Return the keys
- [x] Forward the mail
- [x] Final meter reading
- [x] Cancel the internet

#home
