---
id: 01a0f227-1ae9-7e48-8b29-6f67d2a1a465
kind: note
created: 2026-08-02T10:15:00+00:00
updated: 2026-08-02T10:15:00+00:00
tags: ["home"]
pinned: false
archived: true
---

# Moving checklist (old apartment)

- [x] Return the keys
- [x] Forward the mail
- [x] Final meter reading
- [x] Cancel the internet

#home
