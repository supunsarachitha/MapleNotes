---
id: 01a0f227-1b00-7bf3-a43a-ed98c65428b3
kind: note
created: 2026-08-30T09:12:00+00:00
updated: 2026-08-30T09:12:00+00:00
tags: ["reading/quotes"]
pinned: false
archived: false
---

> Autumn is a second spring when every leaf is a flower.
>
> — Albert Camus

#reading/quotes
