---
id: 01a0ef98-a829-7c68-9cd7-032553ede891
kind: note
created: 2026-08-30T09:12:00+00:00
updated: 2026-08-30T09:12:00+00:00
tags: ["reading/quotes"]
pinned: false
archived: false
---

> Autumn is a second spring when every leaf is a flower.
>
> — Albert Camus

#reading/quotes
