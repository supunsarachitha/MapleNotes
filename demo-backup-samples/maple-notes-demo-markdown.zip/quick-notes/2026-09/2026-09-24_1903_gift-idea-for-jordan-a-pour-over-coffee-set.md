---
id: 01a0ef98-a8a8-70b7-9db0-18f3e7b93a7f
kind: quick
created: 2026-09-24T19:03:00+00:00
updated: 2026-09-24T19:03:00+00:00
tags: []
pinned: false
archived: false
---

Gift idea for Jordan: a pour-over coffee set ☕
