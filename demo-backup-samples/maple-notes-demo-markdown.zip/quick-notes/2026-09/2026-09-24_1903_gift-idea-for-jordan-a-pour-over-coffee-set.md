---
id: 01a0f227-1b80-7ca3-8971-ed05ae0bb05e
kind: quick
created: 2026-09-24T19:03:00+00:00
updated: 2026-09-24T19:03:00+00:00
tags: []
pinned: false
archived: false
---

Gift idea for Jordan: a pour-over coffee set ☕
