---
id: 01a0ef98-a875-70d3-9775-0584f2b47bbc
kind: quick
created: 2026-09-19T08:40:00+00:00
updated: 2026-09-19T08:40:00+00:00
tags: []
pinned: false
archived: false
---

Parking spot at the dentist: level P3, spot 17.
