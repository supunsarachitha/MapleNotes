---
id: 01a0f227-1b51-7c25-a31b-76ad0b38fa5b
kind: quick
created: 2026-09-19T08:40:00+00:00
updated: 2026-09-19T08:40:00+00:00
tags: []
pinned: false
archived: false
---

Parking spot at the dentist: level P3, spot 17.
