---
id: 01a0ef98-a8ce-70c8-b50c-763f9acadb0d
kind: quick
created: 2026-09-29T07:50:00+00:00
updated: 2026-09-29T07:50:00+00:00
tags: []
pinned: false
archived: false
---

Call the vet about the dog's booster shot 🐶
