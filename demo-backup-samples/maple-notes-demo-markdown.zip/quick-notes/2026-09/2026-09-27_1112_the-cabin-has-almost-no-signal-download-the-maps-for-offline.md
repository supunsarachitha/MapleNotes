---
id: 01a0ef98-a8b9-74e5-8036-fd9d61349331
kind: quick
created: 2026-09-27T11:12:00+00:00
updated: 2026-09-27T11:12:00+00:00
tags: []
pinned: false
archived: false
---

The cabin has almost no signal: download the maps for offline use.
