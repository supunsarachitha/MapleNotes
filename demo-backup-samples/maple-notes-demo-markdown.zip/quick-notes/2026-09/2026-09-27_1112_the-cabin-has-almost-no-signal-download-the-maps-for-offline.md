---
id: 01a0f227-1b90-7e10-a0ec-8fecf461944a
kind: quick
created: 2026-09-27T11:12:00+00:00
updated: 2026-09-27T11:12:00+00:00
tags: []
pinned: false
archived: false
---

The cabin has almost no signal: download the maps for offline use.
