---
id: 01a0ef98-a857-7a3e-ad3a-0f72e943db01
kind: quick
created: 2026-09-12T18:05:00+00:00
updated: 2026-09-12T18:05:00+00:00
tags: ["ideas"]
pinned: false
archived: false
---

Idea: a bird feeder camera that only records when a bird lands. #ideas
