---
id: 01a0f227-1b30-7a22-91d0-78a7915e88c1
kind: quick
created: 2026-09-12T18:05:00+00:00
updated: 2026-09-12T18:05:00+00:00
tags: ["ideas"]
pinned: false
archived: false
---

Idea: a bird feeder camera that only records when a bird lands. #ideas
