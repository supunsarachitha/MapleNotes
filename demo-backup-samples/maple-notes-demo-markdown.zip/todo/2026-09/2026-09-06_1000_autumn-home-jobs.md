---
id: 01a0f227-1b1c-74bb-8446-b0b69de475b2
kind: todo
created: 2026-09-06T10:00:00+00:00
updated: 2026-09-20T15:30:00+00:00
tags: ["home"]
pinned: false
archived: false
---

# Autumn home jobs

- [ ] Clean the gutters
- [ ] Swap to winter tires
- [x] Bleed the radiators
- [ ] Rake the leaves (again) #home
