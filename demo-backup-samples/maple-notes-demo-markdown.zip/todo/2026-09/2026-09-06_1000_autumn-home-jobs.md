---
id: 01a0ef98-a846-7c7e-9b75-a3a395a17375
kind: todo
created: 2026-09-06T10:00:00+00:00
updated: 2026-09-20T15:30:00+00:00
tags: ["home"]
pinned: false
archived: false
---

# Autumn home jobs

- [ ] Clean the gutters
- [ ] Swap to winter tires
- [x] Bleed the radiators
- [ ] Rake the leaves (again) #home
