---
id: 01a0f227-1b4b-7d63-b712-da74b7bcb836
kind: todo
created: 2026-09-18T12:35:00+00:00
updated: 2026-09-28T20:15:00+00:00
tags: ["travel"]
pinned: true
archived: false
---

# Algonquin weekend packing

- [x] Tent, poles and pegs
- [x] Sleeping bags (rated to −5 °C)
- [ ] Stove and 2 gas canisters
- [x] Headlamps and spare batteries
- [ ] Rain jackets
- [ ] Maple syrup for the pancakes
- [ ] Camera and a spare battery
- [ ] Book the campsite #travel
