---
id: 01a0ef98-a86f-75d1-8968-1691f9d6e8fd
kind: todo
created: 2026-09-18T12:35:00+00:00
updated: 2026-09-28T20:15:00+00:00
tags: ["travel"]
pinned: true
archived: false
---

# Algonquin weekend packing

- [x] Tent, poles and pegs
- [x] Sleeping bags (rated to −5 °C)
- [ ] Stove and 2 gas canisters
- [x] Headlamps and spare batteries
- [ ] Rain jackets
- [ ] Maple syrup for the pancakes
- [ ] Camera and a spare battery
- [ ] Book the campsite #travel
