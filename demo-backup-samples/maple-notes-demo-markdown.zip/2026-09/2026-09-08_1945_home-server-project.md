---
id: 01a0ef98-a84b-73af-a704-3004047756bb
kind: note
created: 2026-09-08T19:45:00+00:00
updated: 2026-09-25T21:00:00+00:00
tags: ["homelab", "work/projects"]
pinned: false
archived: false
---

# Home server project

Goal: move photos and notes off third-party clouds onto the mini PC.

- [x] Install Docker
- [x] Deploy Maple Notes behind HTTPS
- [ ] Nightly backup to the NAS
- [ ] Test a restore on a spare machine

#work/projects #homelab
