---
id: 01a0f227-1b45-736b-8997-93ae97faf86d
kind: note
created: 2026-09-18T12:20:00+00:00
updated: 2026-09-18T12:20:00+00:00
tags: ["travel"]
pinned: false
archived: false
attachments:
  - "../attachments/b05d70a8_packing-list.txt"
---

# Algonquin trip plans

- **When:** Saturday Oct 3 to Monday Oct 5
- **Where:** Lake of Two Rivers campground
- **Drive:** about 3 hours; leave by 7 am to beat the traffic

The printable packing list is attached; the live one is pinned in **Todo**.

https://en.wikipedia.org/wiki/Algonquin_Provincial_Park

#travel

## Attachments

- [packing-list.txt](../attachments/b05d70a8_packing-list.txt)
