---
id: 01a0ef98-a868-782a-88a0-cee34234bcba
kind: note
created: 2026-09-18T12:20:00+00:00
updated: 2026-09-18T12:20:00+00:00
tags: ["travel"]
pinned: false
archived: false
attachments:
  - "../attachments/6a0158f2_packing-list.txt"
---

# Algonquin trip plans

- **When:** Saturday Oct 3 to Monday Oct 5
- **Where:** Lake of Two Rivers campground
- **Drive:** about 3 hours; leave by 7 am to beat the traffic

The printable packing list is attached; the live one is pinned in **Todo**.

https://en.wikipedia.org/wiki/Algonquin_Provincial_Park

#travel

## Attachments

- [packing-list.txt](../attachments/6a0158f2_packing-list.txt)
