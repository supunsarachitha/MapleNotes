---
id: 01a0f227-1b6d-7766-bf3f-b759f23eb5df
kind: note
created: 2026-09-23T14:30:00+00:00
updated: 2026-09-23T14:30:00+00:00
tags: ["work/meetings"]
pinned: false
archived: false
---

# Sprint planning — week 39

**Attendees:** Alex, Jordan, Priya

- Ship the calendar view to the beta testers
- Jordan looks at the slow export on large accounts
- Next demo: Friday

**Decisions**

1. Keep link previews off by default — they contact other sites.
2. Tag names stay case-insensitive.

#work/meetings
