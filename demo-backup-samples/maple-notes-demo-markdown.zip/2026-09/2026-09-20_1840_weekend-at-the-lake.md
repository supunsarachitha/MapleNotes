---
id: 01a0ef98-a87a-7990-8043-01f6c6210778
kind: note
created: 2026-09-20T18:40:00+00:00
updated: 2026-09-20T18:40:00+00:00
tags: ["photos/trips", "travel"]
pinned: false
archived: false
attachments:
  - "../attachments/958047dc_autumn-sunset.jpg"
  - "../attachments/8f16112a_lake-morning.jpg"
  - "../attachments/e87f7fda_forest-trail.jpg"
---

# Weekend at the lake

Three shots from the weekend: sunset over the ridge, mist on the lake at 7 am, and the trail through the maples. Tap a photo to open the viewer, then swipe or use the arrow keys.

#photos/trips #travel

## Attachments

- ![autumn-sunset.jpg](../attachments/958047dc_autumn-sunset.jpg)
- ![lake-morning.jpg](../attachments/8f16112a_lake-morning.jpg)
- ![forest-trail.jpg](../attachments/e87f7fda_forest-trail.jpg)
