---
id: 01a0f227-1b57-746e-95d2-98faa84af2a2
kind: note
created: 2026-09-20T18:40:00+00:00
updated: 2026-09-20T18:40:00+00:00
tags: ["photos/trips", "travel"]
pinned: false
archived: false
attachments:
  - "../attachments/b936f3b4_autumn-sunset.jpg"
  - "../attachments/6bad085e_lake-morning.jpg"
  - "../attachments/f67e9475_forest-trail.jpg"
---

# Weekend at the lake

Three shots from the weekend: sunset over the ridge, mist on the lake at 7 am, and the trail through the maples. Tap a photo to open the viewer, then swipe or use the arrow keys.

#photos/trips #travel

## Attachments

- ![autumn-sunset.jpg](../attachments/b936f3b4_autumn-sunset.jpg)
- ![lake-morning.jpg](../attachments/6bad085e_lake-morning.jpg)
- ![forest-trail.jpg](../attachments/f67e9475_forest-trail.jpg)
