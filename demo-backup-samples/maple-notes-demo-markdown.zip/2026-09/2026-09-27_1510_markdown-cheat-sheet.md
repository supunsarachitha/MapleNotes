---
id: 01a0ef98-a8be-7a4c-977a-f6a44ca64748
kind: note
created: 2026-09-27T15:10:00+00:00
updated: 2026-09-27T15:10:00+00:00
tags: ["reference/markdown"]
pinned: false
archived: false
---

# Markdown cheat sheet

Maple Notes understands **bold**, *italic*, ~~strikethrough~~, `inline code` and [links](https://commonmark.org/help/).

## Lists

1. Numbered items
2. keep their order
   - and can nest
   - bullet points

- [x] Checklists work in any note
- [ ] not only in todo lists

## Table

| Tree | Autumn colour | Good for syrup |
| --- | --- | :---: |
| Sugar maple | orange-red | ✅ |
| Red maple | scarlet | ✅ |
| Silver maple | pale yellow | ⚠️ thin |

## Quote

> The best time to plant a tree was twenty years ago. The second best time is now.

## Code

```bash
# back up the data volume
docker run --rm -v maple-notes-data:/data -v "$PWD":/out alpine \
  tar czf /out/maple-backup.tgz -C /data .
```

---

The toolbar above the editor inserts all of these. #reference/markdown
