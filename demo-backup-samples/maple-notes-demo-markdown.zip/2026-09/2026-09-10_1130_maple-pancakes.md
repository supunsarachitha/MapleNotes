---
id: 01a0f227-1b29-7f83-9569-8f32960aca9a
kind: note
created: 2026-09-10T11:30:00+00:00
updated: 2026-09-10T11:30:00+00:00
tags: ["recipes/breakfast"]
pinned: false
archived: false
attachments:
  - "../attachments/902ca3c1_maple-pancakes.pdf"
---

# Maple pancakes

Grandma's recipe card is attached as a PDF; the short version:

| Ingredient | Amount |
| --- | --- |
| Flour | 1½ cups |
| Baking powder | 3½ tsp |
| Milk | 1¼ cups |
| Egg | 1 |
| Butter, melted | 3 tbsp |
| Maple syrup | plenty |

1. Whisk the dry ingredients.
2. Add the milk, egg and butter; stir until just combined.
3. Cook on a hot griddle until bubbles form, then flip.

#recipes/breakfast

## Attachments

- [maple-pancakes.pdf](../attachments/902ca3c1_maple-pancakes.pdf)
