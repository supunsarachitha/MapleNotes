---
id: 01a0f227-1b37-76d2-ae55-188c52b042fb
kind: note
created: 2026-09-14T16:05:00+00:00
updated: 2026-09-14T16:05:00+00:00
tags: ["garden", "video"]
pinned: false
archived: false
attachments:
  - "../attachments/7cc473ff_garden-timelapse.mp4"
---

# Garden time-lapse

An 8-second test clip for the garden club slideshow. Videos play right in the note.

#garden #video

## Attachments

- [garden-timelapse.mp4](../attachments/7cc473ff_garden-timelapse.mp4)
