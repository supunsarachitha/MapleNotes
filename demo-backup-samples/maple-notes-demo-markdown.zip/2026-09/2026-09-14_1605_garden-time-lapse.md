---
id: 01a0ef98-a85d-7ef4-94a4-10edbc987d37
kind: note
created: 2026-09-14T16:05:00+00:00
updated: 2026-09-14T16:05:00+00:00
tags: ["garden", "video"]
pinned: false
archived: false
attachments:
  - "../attachments/936ae57f_garden-timelapse.mp4"
---

# Garden time-lapse

An 8-second test clip for the garden club slideshow. Videos play right in the note.

#garden #video

## Attachments

- [garden-timelapse.mp4](../attachments/936ae57f_garden-timelapse.mp4)
