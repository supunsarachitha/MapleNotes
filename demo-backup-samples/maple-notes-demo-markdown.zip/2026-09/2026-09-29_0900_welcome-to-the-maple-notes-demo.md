---
id: 01a0f227-1bad-7f3b-9a3c-f803902670c5
kind: note
created: 2026-09-29T09:00:00+00:00
updated: 2026-09-29T09:00:00+00:00
tags: ["garden/log", "tag", "welcome", "work/meetings"]
pinned: true
archived: false
---

# Welcome to the Maple Notes demo 🍁

This account is sample data for trying every feature. Nothing here is real, so edit, tick, archive and delete freely.

**Where to look**

- **Home**: this timeline. Pinned notes stay on top; search finds any word or #tag.
- **Todo**: checklists to tick off as you go. The packing list is pinned.
- **Quick notes**: short jottings kept out of the timeline.
- **Calendar**: dots mark the days with notes; there are daily notes for most of the week of September 21.
- **Tags**: nested tags such as #work/meetings and #garden/log.
- **Archive**: two old notes are tucked away there.
- **Habits**: three habits with ten weeks of history, a progress chart and streaks, and an archived one. Turn on the **Habit tracker** in Settings → Features to see them.

**Try these**

- Open the *Weekend at the lake* photos in the image viewer.
- Play the garden time-lapse video and the voice memo.
- Download the pancake recipe PDF and the garden log CSV.
- Turn on **Note titles**, **Daily notes**, the **Habit tracker** and **Link previews** in Settings. Settings are not part of a backup, so they start at their defaults.
- **Settings → Account** shows how much this account stores.

#welcome
